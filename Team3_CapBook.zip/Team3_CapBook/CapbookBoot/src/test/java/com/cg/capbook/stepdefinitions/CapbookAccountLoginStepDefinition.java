package com.cg.capbook.stepdefinitions;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.capbook.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class CapbookAccountLoginStepDefinition {
	
	private WebDriver webDriver;
	private LoginPage loginPage;
	
	@Given("^User is on the CapBook home page$")
	public void user_is_on_the_CapBook_home_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\159938_Pankush_Kapoor\\chromedriver.exe");
		webDriver = new ChromeDriver();
		webDriver.get("http://localhost:4200/login");
		loginPage=PageFactory.initElements(webDriver, LoginPage.class);
	   
	}

	@When("^User enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		loginPage.setEmailId("abhi@gmail.com");
		loginPage.setPassword("asd");
		loginPage.onClick();
	   
	}

	@Then("^User is navigated to CapBook Home Page$")
	public void user_is_navigated_to_CapBook_Home_Page() throws Throwable {

		String actualTitle= webDriver.getPageSource();
		boolean isTheTextPresent = webDriver.getPageSource().contains("Welcome");
		assertTrue(isTheTextPresent);
		webDriver.close();
		
	}

	@When("^User enters invalid email Id or User enters invalid password$")
	public void user_enters_invalid_email_Id_or_User_enters_invalid_password() throws Throwable {
		loginPage.setEmailId("abhi@gmail.com");
		loginPage.setPassword("22");
		loginPage.onClick();
	  
	}

	@Then("^User remains on CapBook Home Page with an error message$")
	public void user_remains_on_CapBook_Home_Page_with_an_error_message() throws Throwable {
		String actualTitle= loginPage.getActualErrorMessage();
		String expectedTitle="Please Enter correct Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		webDriver.close();
		
	}

}
