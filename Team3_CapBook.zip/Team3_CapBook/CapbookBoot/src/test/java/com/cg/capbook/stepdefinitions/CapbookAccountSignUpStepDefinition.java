/*package com.cg.capbook.stepdefinitions;
import static org.junit.Assert.assertTrue;

import javax.validation.constraints.AssertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.capbook.pagebeans.SignUpPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class CapbookAccountSignUpStepDefinition {
	private WebDriver webDriver;
	private static SignUpPage signUpPage;
	

	@Given("^User is on the Capbook 'SignUp Page'$")
	public void user_is_on_the_Capbook_SignUp_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"D:\\159938_Pankush_Kapoor\\chromedriver.exe");
		webDriver = new ChromeDriver();
		webDriver.get("http://localhost:4200/signup");
		signUpPage=PageFactory.initElements(webDriver, SignUpPage.class);
	    
	}

	@When("^User enters all valid details$")
	public void user_enters_all_valid_details() throws Throwable {
		signUpPage.setBio("qwerty");
		signUpPage.setEmailId("nikhil123@gmail.com");
		signUpPage.setName("Nik");
		signUpPage.setPassword("123");
		signUpPage.setPhoneNo("7895644637");
		signUpPage.setSecurityQuestion("Don");
		signUpPage.setUserName("nnn");
		signUpPage.setDateofBirth("10/08/2017");
		signUpPage.onClick();
	  
	}

	@Then("^User is directed to 'HomePage'$")
	public void user_is_directed_to_HomePage() throws Throwable {
		String actualTitle= webDriver.getPageSource();
		boolean isTheTextPresent = webDriver.getPageSource().contains("Nik");
		assertTrue(isTheTextPresent);
		webDriver.close();
	   
	}

}
*/