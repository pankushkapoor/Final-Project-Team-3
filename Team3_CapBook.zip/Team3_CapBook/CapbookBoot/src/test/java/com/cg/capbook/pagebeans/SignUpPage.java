/*package com.cg.capbook.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SignUpPage {
	public SignUpPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	@FindBy(how=How.NAME, name="email")
	private WebElement emailId;
	
	@FindBy(how=How.NAME, name="password")
	private WebElement password;
	
	@FindBy(how=How.NAME, name="name")
	private WebElement name;
	
	@FindBy(how=How.ID, id="userName")
	private WebElement userName;
	
	@FindBy(how=How.NAME, name="dateOfBirth")
	private WebElement dateofBirth;

	@FindBy(how=How.NAME, name="gender")
	private WebElement gender;
	
	@FindBy(how=How.NAME, name="phoneNo")
	private WebElement phoneNo;
	
	@FindBy(how=How.NAME, name="bio")
	private WebElement bio;
	
	@FindBy(how=How.ID, id="securityQuestion")
	private WebElement securityQuestion;
	
	@FindBy(how=How.ID,id="submit")
	private WebElement button;

	public String getEmailId() {
		return emailId.getAttribute("value");
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public String getName() {
		return name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getUserName() {
		return userName.getAttribute("value");
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public String getDateofBirth() {
		return dateofBirth.getAttribute("value");
	}

	public void setDateofBirth(String dateofBirth) {
		this.dateofBirth.sendKeys(dateofBirth);
	}

	public String getGender() {
		return gender.getAttribute("value");
	}

	public void setGender(String gender) {
		this.gender.sendKeys(gender);
	}

	public String getPhoneNo() {
		return phoneNo.getAttribute("value");
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo.sendKeys(phoneNo);
	}

	public String getBio() {
		return bio.getAttribute("value");
	}

	public void setBio(String bio) {
		this.bio.sendKeys(bio);
	}

	public String getSecurityQuestion() {
		return securityQuestion.getAttribute("value");
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion.sendKeys(securityQuestion);
	}
	
	public void onClick() {
		button.click();
	}
}
*/