package com.cg.capbook.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.capbook.beans.Post;

public interface PostDAO extends JpaRepository<Post, Integer> {

	@Query(value="SELECT * FROM post where user_email_Id=?1",nativeQuery=true)
	public List<Post> getPosts(String email);
	
	@Modifying
	@Transactional
	@Query(value="update post set likes=(likes+1) where post_id=?1",nativeQuery=true)
	public void likePost(int postId);
}
