package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Post {
	@Id
	@SequenceGenerator(name="post_seq",sequenceName="post_seq",initialValue=101,allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="post_seq")
	private int postId;
	private String postContent;
	private String senderName;
	private String emailId;
	private String checkLike;
	private int imgId;
	@JsonBackReference
	@ManyToOne
	private Users user;
	private int likes;
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public int getPostId() {
		return postId;
	}
	public void setPostId(int postId) {
		this.postId = postId;
	}
	public String getPostContent() {
		return postContent;
	}
	public void setPostContent(String postContent) {
		this.postContent = postContent;
	}
	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}	
	
	@Override
	public String toString() {
		return "Post [postId=" + postId + ", postContent=" + postContent + ", senderName=" + senderName + ", emailId="
				+ emailId + ", user=" + user + ", likes=" + likes + "]";
	}
	public Post() {
		super();
	}
	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Post(String postContent, Users user) {
		super();
		this.postContent = postContent;
		this.user = user;
		this.emailId=user.getEmailId();
	}
	public int getImgId() {
		return imgId;
	}
	public void setImgId(int imgId) {
		this.imgId = imgId;
	}
	public String getCheckLike() {
		return checkLike;
	}
	public void setCheckLike(String checkLike) {
		this.checkLike = checkLike;
	}
	
	
	
}
