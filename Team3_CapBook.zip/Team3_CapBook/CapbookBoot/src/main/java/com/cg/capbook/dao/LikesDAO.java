package com.cg.capbook.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.capbook.beans.Likes;

public interface LikesDAO extends JpaRepository<Likes, Integer>{
	
	@Query(value="SELECT post_id from likes where liked_by=?1",nativeQuery=true)
	public List<BigDecimal> checkLike(String email);
	
	@Query(value="SELECT liked_by from likes where liked_by=?1 and post_id=?2",nativeQuery=true)
	public List<String> checked(String email,int postId);
}
