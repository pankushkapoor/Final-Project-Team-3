import { Component, OnInit } from '@angular/core';
import { Profile } from 'src/app/profiles/profile/profileInterface';
import { User } from '../user/userInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit {

  error: string;
  flag: string='zero';
  profile1:Profile;
  user3: User;
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    this.user3 = JSON.parse(localStorage.getItem('user'));
  }
  public goToHome():void{
    this.router.navigate(['/homePage'])
  }

  public viewProfile():void{
    this.router.navigate(['/profile']);
  }

  public viewNotifications():void{
    this.router.navigate(['/Notification'])
  }

  public goToAlbum():void{
    this.router.navigate(['/albums']);
  }
  public logout():void{
    this.capBookService.logout();
  }
  public viewMessages():void{
    location.reload();
  }
}
