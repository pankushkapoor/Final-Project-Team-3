export interface Post {
    postId: number;
    postContent: string;
    senderName: string;
    emailId: string;
    likes : number;
    imgId: number;
    checkLike:string;
}
