import { Injectable } from '@angular/core';
import { User } from '../users/user/userInterface';
import { Profile } from '../profiles/profile/profileInterface';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators'
import { throwError, Observable } from 'rxjs';
import { Post } from '../post/post-interface';
import { Router } from '@angular/router';
import { utf8Encode } from '@angular/compiler/src/util';
import { stringify } from 'querystring';

@Injectable({
  providedIn: 'root'
})
export class CapBookServicesService {

  user: User;
  profile: Profile;
  post: Post;
  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(private httpClient: HttpClient, private router: Router) { }

  public signUpUser(user: User): any {
    return this.httpClient.post<User>("http://localhost:5558/acceptUserDetails", user, { headers: this.headers }).pipe(catchError(this.handleError));

  }
  public loginUser(user: User): any {
    return this.httpClient.post<User>("http://localhost:5558/loginUser", user, { headers: this.headers }).pipe(catchError(this.handleError));

  }

  public likePost(postId:number,emailId:string){
    let params = new HttpParams();
    params = params.set('emailId', emailId.toString());
    params = params.set('postId', postId.toString());
    console.log("post id is "+postId+" email id is "+emailId)
    return this.httpClient.get<Post>("http://localhost:5558/likePost", { params: params }).pipe(catchError(this.handleError));
  }

  
  public getUserDetails(emailId: string): any {
    let params = new HttpParams();
    params = params.set('emailId', emailId.toString());
    return this.httpClient.get<User>("http://localhost:5558/getUserDetails", { params: params }).pipe(catchError(this.handleError));

  }

  public getProfileDetails(userName: string): any {
    let params = new HttpParams();
    params = params.set('userName', userName.toString());
    return this.httpClient.get<Profile>("http://localhost:5558/getProfileDetails", { params: params }).pipe(catchError(this.handleError));

  }
  public searchFriend(name: string): any {
    let params = new HttpParams();
    params = params.set('name', name.toString());
    return this.httpClient.get<Profile[]>("http://localhost:5558/searchFriend", { params: params }).pipe(catchError(this.handleError));

  }
  public updateProfile(user: User): Observable<User> {
    return this.httpClient.post<User>("http://localhost:5558/updateProfile", user, { headers: this.headers }).pipe(catchError(this.handleError));
  }
  public updateUser(user: User): Observable<User> {
    return this.httpClient.post<User>("http://localhost:5558/updateUser", user, { headers: this.headers }).pipe(catchError(this.handleError));
  }

  public addPost(post: Post, email: string): Observable<Post> {
    let params = new HttpParams;
    params = params.set('post', post.postContent.toString());
    params = params.set('emailId', email.toString());//this.user.emailId.toString());
    return this.httpClient.get<Post>("http://localhost:5558/addPost", { params: params }).pipe(catchError(this.handleError));
  }

  public getAllPosts(email: string): Observable<Post[]> {
    let params = new HttpParams();
    params = params.set('emailId', email.toString());
    return this.httpClient.get<Post[]>("http://localhost:5558/getAllPosts", { params: params }).pipe(catchError(this.handleError));
  }

  public getMyPosts(email: string): Observable<Post[]> {
    let params = new HttpParams();
    params = params.set('emailId', email.toString());
    return this.httpClient.get<Post[]>("http://localhost:5558/getMyPosts", { params: params }).pipe(catchError(this.handleError));
  }
  public getFriendPosts(userName: string): Observable<Post[]> {
    let params = new HttpParams();
    params = params.set('userName', userName.toString());
    return this.httpClient.get<Post[]>("http://localhost:5558/getFriendPosts", { params: params }).pipe(catchError(this.handleError));
  }

  public getAllNotifications(email: string): Observable<Notification[]> {
    let params = new HttpParams();
    params = params.set('emailId', email.toString());
    return this.httpClient.get<Notification[]>("http://localhost:5558/getAllNotifications", { params: params }).pipe(catchError(this.handleError));
  }

  public addFriend(email: string, userName: string) {
    let params = new HttpParams;
    params = params.set('emailId', email);
    params = params.set('userName', userName);
    return this.httpClient.get<User>("http://localhost:5558/addFriend", { params: params}).pipe(catchError(this.handleError));
  }

  public postFile(fileToUpload: File,emailId:string):any {
    const formData: FormData = new FormData();
    formData.append('Image', fileToUpload, fileToUpload.name);
    formData.set('emailId',emailId)
    return this.httpClient.post("http://localhost:5558/upload", formData).pipe( map(() => { return true; }),
    catchError(this.handleError));
  }

  public getAllFriends(emailId:string):any{
    let params=new HttpParams();
    params=params.set('emailId',emailId);
    return this.httpClient.get<Profile[]>("http://localhost:5558/getAllFriends",{params:params}).pipe(catchError(this.handleError));

  }
  public getProfilePic(emailId:string):any{
    let params=new HttpParams();
    params=params.set('emailId',emailId);
    console.log('emailId is '+emailId)
    return this.httpClient.get<Profile>("http://localhost:5558/getProfilePic",{params:params}).pipe(catchError(this.handleError));
  }
  public getFriendPic(userName:string):any{
    let params=new HttpParams();
    params=params.set('userName',userName);
    return this.httpClient.get<Profile>("http://localhost:5558/getFriendPic",{params:params}).pipe(catchError(this.handleError));
  }
  public getAllPics(emailId:string):any{
    let params=new HttpParams();
    params=params.set('emailId',emailId);
    console.log('emailId is ++++'+emailId)
    return this.httpClient.get<Profile>("http://localhost:5558/getAllPics",{params:params}).pipe(catchError(this.handleError));
  }
  public addFriendRequest(email: string, userName:string){
    let params=new HttpParams;
    params=params.set('emailId',email);
    params=params.set('userName',userName);
    return this.httpClient.get<User>("http://localhost:5558/addFriendRequest",{params:params}).pipe(catchError(this.handleError));
  }

  public removeNotification(notId: number) {
    let params = new HttpParams;
    params = params.set('notId', notId.toString());
    console.log("value is " + notId)
    return this.httpClient.get<Notification>("http://localhost:5558/removeNotification", { params: params }).pipe(catchError(this.handleError));
  }
  public removePost(postId:number): Observable<string[]> {
    let params = new HttpParams();
      params = params.set('postId',postId.toString());
    return this.httpClient.get<string[]>
      ("http://localhost:5558/removePost", { params: params }).pipe(catchError(this.handleError));
  }

  public logout(): void {
    localStorage.setItem('isLoggedIn', 'false');
    localStorage.removeItem('user');
    this.router.navigate(['/login']);
  }
  private handleError(error: any) {
    if (error instanceof ErrorEvent) {
      console.error('1 An ErrorEvent occurred:', error.error.message);
      return throwError(error.error.message);
    } else if (error instanceof HttpErrorResponse) {
      console.error(`2 Backend returned code ${error.status},body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status},body was: ${error.message}`);
    }
    else if (error instanceof TypeError) {
      console.error(`3 TypeError has occured ${error.message}, body was ${error.stack}`)
      return throwError(`TypeError has occured ${error.message}, body was ${error.stack}`)
    }
  }
}
