import { TestBed } from '@angular/core/testing';

import { CapBookServicesService } from './cap-book-services.service';

describe('CapBookServicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CapBookServicesService = TestBed.get(CapBookServicesService);
    expect(service).toBeTruthy();
  });
});
