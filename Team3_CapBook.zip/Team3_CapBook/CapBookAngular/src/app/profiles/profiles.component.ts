import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';
import { Post } from '../post/post-interface';
import { Profile } from './profile/profileInterface';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css']
})
export class ProfilesComponent implements OnInit {
  error: string;
  flag: string='zero';
  profile1:Profile;
  profile2:Profile = {
    name: "",
    gender: "",
    phoneNo: "",
    dateOfBirth: "", 
    bio: "",
    userName: ""
  }
  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }
  post: Post = {
    postId:0,
    postContent:"",
    senderName:"",
    emailId:"",
    likes:0,
    imgId:0,
    checkLike:""
  }
  postList:Post[];
  user3: User;
  fileToUpload:File
  imgId:string
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    //const _user=this.route.snapshot.paramMap.get('emailId');
    this.user3 = JSON.parse(localStorage.getItem('user'));
    this.user = JSON.parse(localStorage.getItem('user'));
    this.profile1 = this.user.profile;
    this.capBookService.getProfilePic(this.user.emailId).subscribe(
      profile =>{
        this.profile2=profile;
        console.log('inside prfofile pic su')
        console.log(this.profile2.phoneNo) 
        this.imgId=this.profile2.phoneNo
      }
    );
    this.imgId=this.profile2.phoneNo;
    this.capBookService.getUserDetails(this.user3.emailId).subscribe(
      user1=>{
      this.user=user1;
    },
    errorMessage=>{
      this.error=errorMessage
    }) ; 
    
    this.capBookService.getProfileDetails(this.user3.profile.userName).subscribe(
      profile1=>{
      this.profile1=profile1;
    },
    errorMessage=>{
      this.error=errorMessage
    });
    this.capBookService.getMyPosts(this.user3.emailId).subscribe(
      posts =>{
        console.log(posts);
        this.postList=posts;
        //this.postList=this.postList.reverse(); 
      }
    );
  }
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    this.uploadFileToActivity();
}
  uploadFileToActivity() {
    console.log("in upload");
    this.capBookService.postFile(this.fileToUpload,this.user.emailId).subscribe(
     
      data => {
      console.log("success");
      window.location.reload();
      }, 
       error => {
        console.log(error);
        window.location.reload();
        
      });
    
    }

 
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage'])
  }
  public editProfile(){
    this.flag='one';
 //this.router.navigate(['/profile',{"emailId":this.user.profile.emailId}])
 this.router.navigate(['/profile'])
  }

  public viewProfile():void{
    location.reload();
  }
  public viewFriendProfile(profile):void{
    localStorage.setItem('friendProfile',JSON.stringify(profile));
    this.router.navigate(['/friendProfile'])
  }
  public viewNotifications():void{
    this.router.navigate(['/Notification'])
  }

  public goToAlbum():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/albums']);
  }

  public viewMessages():void{
    this.router.navigate(['/messages'])
  }
  public removePost(post:Post):void{
    
    this.capBookService.removePost(post.postId).subscribe(
      postList=>{
        console.log("hiiiiiiiiiiiiiiiiiii")
          this.post.postId=null;
          location.reload();
  }
    );
}
  public logout():void{
    this.capBookService.logout();
  }

  public viewFriends(){
    this.router.navigate(['/viewFriends'])
  }
  public updateProfile(){
    this.flag='zero';
    console.log(this.user.profile.name)
     this.capBookService.updateProfile(this.user).subscribe(profile1=>{
      this.user = profile1;
    },
    errorMessage=>{
      this.error = errorMessage;
    });
  }
}
