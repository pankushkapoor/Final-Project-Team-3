export interface Profile{
    name: string;
    gender: string;
    phoneNo: string;
    dateOfBirth: string;
    bio: string;
    userName: string;
}