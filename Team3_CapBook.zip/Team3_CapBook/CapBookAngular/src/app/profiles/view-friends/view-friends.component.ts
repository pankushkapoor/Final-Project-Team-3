import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/users/user/userInterface';
import { Profile } from '../profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from 'src/app/services/cap-book-services.service';

@Component({
  selector: 'app-view-friends',
  templateUrl: './view-friends.component.html',
  styleUrls: ['./view-friends.component.css']
})
export class ViewFriendsComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  error : string;
  friendProfiles : Profile[];
  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: ""
            },
    securityQuestion: ""
  }
  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));

    this.capBookService.getAllFriends(this.user.emailId).subscribe(
      friends =>{
        this.friendProfiles=friends;
      }
    ) 

  }
  public logout():void{
    this.capBookService.logout();
  }
 
   public exit() {
    location.reload();
  }
  public viewProfile():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/profile'])
  }
  public viewFriendProfile(profile):void{
    localStorage.setItem('friendProfile',JSON.stringify(profile));
    this.router.navigate(['/friendProfile'])
  }
  public viewNotifications():void{
    this.router.navigate(['/Notification',{"emailId":this.user.emailId}])
  }
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage',{"emailId":this.user.profile.userName}])
  }

  public viewMessages():void{
    this.router.navigate(['/messages'])
  }

  public goToAlbum():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/albums']);
  }

}
  
