export interface Notification {
    id:number;
    notMsg:string;
    status:string;
    type:string;
    msgTo:string;
    name:string;
}
