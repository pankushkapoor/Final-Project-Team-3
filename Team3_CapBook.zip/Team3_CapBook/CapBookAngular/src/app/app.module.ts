import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersComponent } from './users/users.component';
import { HttpClientModule } from '@angular/common/http';
import { SignUpUserComponent } from './users/sign-up-user/sign-up-user.component';
import { RouterModule } from '@angular/router';
import { ProfilesComponent } from './profiles/profiles.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginUserComponent } from './users/login-user/login-user.component';
import { HomePageComponent } from './homePage/home-page.component';
import { AlbumsComponent } from './profiles/albums/albums.component';
import { FriendProfileComponent } from './profiles/friend-profile/friend-profile.component';
import { NotificationComponent } from './notification/notification.component';
import { AuthorizeService } from './Authorize/authorize.service';
import { MessagesComponent } from './users/messages/messages.component';
import { ViewFriendsComponent } from './profiles/view-friends/view-friends.component';

@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    SignUpUserComponent,
    ProfilesComponent,
    WelcomeComponent,
    LoginUserComponent,
    HomePageComponent,
    AlbumsComponent,
    FriendProfileComponent,
    NotificationComponent,
    MessagesComponent,
    ViewFriendsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path:'Notification', component : NotificationComponent, canActivate:[AuthorizeService]},
      { path:'messages', component : MessagesComponent, canActivate:[AuthorizeService]},
      { path:'homePage',component: HomePageComponent, canActivate:[AuthorizeService]},
      { path:'albums',component: AlbumsComponent, canActivate:[AuthorizeService]},
      { path:'profile',component: ProfilesComponent, canActivate:[AuthorizeService]},
      { path:'profile/:emailId',component: ProfilesComponent, canActivate:[AuthorizeService]},
      { path:'friendProfile',component: FriendProfileComponent, canActivate:[AuthorizeService]},
      { path:'signup',component: SignUpUserComponent},
      { path:'login',component: LoginUserComponent},
      { path: 'viewFriends',component: ViewFriendsComponent},
      { path: 'welcome',component:  WelcomeComponent},
      { path: '',redirectTo:'welcome',pathMatch:'full'}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
