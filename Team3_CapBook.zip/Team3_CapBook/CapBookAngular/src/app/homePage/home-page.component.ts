import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { Profile } from '../profiles/profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';
import { Post } from '../post/post-interface';
import { NgForm } from '@angular/forms';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  pageTitle="Welcome!";
  error: string;
  flag: string='zero';
  flag1: string='zero';
  postDummy:Post;
  postTest:Post;
  profile1:Profile;
  profile2:Profile = {
    name: "",
    gender: "",
    phoneNo: "",
    dateOfBirth: "", 
    bio: "",
    userName: ""
  }
  profileDummy:Profile = {
    name: "",
    gender: "",
    phoneNo: "",
    dateOfBirth: "", 
    bio: "",
    userName: ""
  }
  dummyArray:Profile[]
  user: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }
  user1: User = {
    emailId: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              userName: "",
            },
    securityQuestion: ""
  }
  profileList: Profile[];
  post: Post = {
    postId:0,
    postContent:"",
    senderName:"",
    emailId:"",
    likes:0,
    imgId:0,
    checkLike:""
  }
  postList:Post[];
  notifications:Notification[]
  user3: User;
  fileToUpload:File
  imgId:string;
  like:string = 'zero';
  

  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    this.user3 = JSON.parse(localStorage.getItem('user'));
    // const _user=this.route.snapshot.paramMap.get('emailId');
    this.user = JSON.parse(localStorage.getItem('user'));
    this.profile1 = this.user.profile; 
   
    this.capBookService.getAllPosts(this.user3.emailId).subscribe(
      posts =>{
        posts.forEach(element => {
          this.capBookService.getProfilePic(element.emailId).subscribe(
            profile8 =>{
              element.imgId=parseInt(profile8.phoneNo)
              this.postList.push(element)
            }
          ); 
       });
        this.postList=this.postList.reverse();
     }
    )
    this.capBookService.getAllNotifications(this.user.emailId).subscribe(
      notes =>{
        this.notifications=notes;
      }
    )


    this.capBookService.getProfilePic(this.user.emailId).subscribe(
      profile =>{
        this.profile2=profile;
        console.log('inside prfofile pic su')
        console.log(this.profile2.phoneNo)
        this.imgId=this.profile2.phoneNo
      }
    );
    this.imgId=this.profile2.phoneNo;
    this.capBookService.getUserDetails(this.user3.emailId).subscribe(
      user1=>{
      this.user=user1;
    },
    errorMessage=>{
      this.error=errorMessage
    }) ;
    this.capBookService.getUserDetails(this.user3.emailId).subscribe(
      user=>{
      this.user=user;
    },
    errorMessage=>{
      this.error=errorMessage;
    })    
    
    this.capBookService.getMyPosts(this.user3.emailId).subscribe(
      posts =>{
        this.postList=posts;
      }
    )
    /* this.capBookService.getAllPosts(this.user3.emailId).subscribe(
      posts =>{
        posts.forEach(element => {
          this.postList.push(element)
        });
        this.postList=this.postList.reverse();
      }
    )  */
    this.capBookService.getProfileDetails(this.user3.profile.userName).subscribe(
      profile1=>{
      this.user.profile=profile1;
    },
    errorMessage=>{
      this.error=errorMessage;
    }) 
    localStorage.getItem('user');
    
  }
  public logout():void{
    this.capBookService.logout();
  }

  public likePost(post){
    console.log("post id is "+post.postId+" email id is "+this.user.emailId)
    this.capBookService.likePost(post.postId,this.user.emailId).subscribe(post=>{
      this.postTest=post;
    })
    location.reload();
  }
 /* public unlikePost(post){
    console.log("post id is "+post.postId+" email id is "+this.user.emailId)
    this.capBookService.unlikePost(post.postId,this.user.emailId).subscribe(post=>{
      this.postTest=post;
    })
    location.reload();
  } */
 
   public exit() {
    location.reload();
  }
  public viewProfile():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/profile'])
  }
  public viewFriendProfile(profile):void{
    localStorage.setItem('friendProfile',JSON.stringify(profile));
    this.router.navigate(['/friendProfile'])
  }
  public viewNotifications():void{
    this.router.navigate(['/Notification',{"emailId":this.user.emailId}])
  }
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage',{"emailId":this.user.profile.userName}])
  }

  public viewMessages():void{
    this.router.navigate(['/messages'])
  }

  public goToAlbum():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/albums']);
  }
  public closeShowUsers():void{
    this.flag1="one";
    this.router.navigate(['/homePage']);
  }
/*   public addPost():void{
    this.capBookService.addPost(this.post).subscribe(post => {
    this.post = post;
    this.router.navigate(['/homePage'])
      
     },
     errorMessage=>{
    this.error="Post not added";
     }); */
//  }
public addPost(myForm: NgForm):any{
  this.capBookService.addPost(this.post, this.user.emailId).subscribe(post => {
  this.post = post;
  this.exit();
   // this.router.navigate(['/homePage',{'emailId': this.user.emailId}])
 },
errorMessage=>{
   this.error=errorMessage;
  });
}
public addFriendRequest(profile : Profile){
  this.capBookService.addFriendRequest(this.user.emailId,profile.userName).subscribe(tempUser => {
     this.exit();
   },
  errorMessage=>{
     this.error=errorMessage;
    });
}

  public searchFriend():any{
    if(this.user1.profile.name!=''){
      this.capBookService.searchFriend(this.user1.profile.name).subscribe(profileList1 => {
        this.profileList = profileList1;
        if(this.profileList.length!=0){
          this.flag1="zero";
          this.flag='zero';
          this.router.navigate(['/homePage'])
        }
        else{
          this.flag='one';
          this.error="No user with this name";
        }
      },
      errorMessage=>{
        // this.flag='one';
        //this.error="No user with this name";
      });
    }
  }

}
